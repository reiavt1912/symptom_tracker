import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:symptom_tracker/app/sign_in/sign_in_button.dart';
import 'package:symptom_tracker/app/sign_in/social_sign_in.dart';
import 'package:symptom_tracker/services/auth.dart';

class SignInPage extends StatelessWidget {
  const SignInPage({Key? key,  required this.auth}) : super(key: key);
  final AuthBase auth;

  Future<void> _signInAnonymously() async {
    try {
      await auth.signInAnonymously();
    } catch (e) {
      if (kDebugMode) {
        print(e.toString());
      }
    }
  }

  Future<void> _signInWithGoogle() async {
    try {
      await auth.signInWithGoogle();
    } catch (e) {
      if (kDebugMode) {
        print(e.toString());
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Symptom Tracker'),
        elevation: 2.0,
        centerTitle: true,
      ),
      body: _buildContent(),
    );
  }

  Widget _buildContent() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          const Text(
            'Sign in',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 32.0,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 40.0),
          SocialSignInButton(
            image: 'google-logo.png',
            text: 'Sign in with Google',
            onPressed: _signInWithGoogle,
            onPrimary: Colors.black87,
            primary: Colors.white,
          ),
          const SizedBox(height: 8.0),
          SocialSignInButton(
              primary: const Color(0xFF334D92),
              onPrimary: Colors.white,
              onPressed: () {},
              image: 'facebook-logo.png',
              text: 'Sign in with Facebook'),
          const SizedBox(height: 8.0),
          SignInButton(
              child: const Text('Sign in with email'),
              primary: Colors.teal,
              onPrimary: Colors.white,
              onPressed: _signInAnonymously),
        ],
      ),
    );
  }
}
